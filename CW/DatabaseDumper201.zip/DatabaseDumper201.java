import java.sql.*;
import java.util.*;

/**
 * Class which needs to be implemented.  ONLY this class should be modified
 */
public class DatabaseDumper201 extends DatabaseDumper {
  
    /**
     * 
     * @param c connection which the dumper should use
     * @param type a string naming the type of database being connected to e.g. sqlite
     */
    public DatabaseDumper201(Connection c,String type) {
        super(c,type);
    }
    /**
     * 
     * @param c connection to a database which will have a sql dump create for
     */
    public DatabaseDumper201(Connection c) {
        super(c,c.getClass().getCanonicalName());
    }

    public List<String> getTableNames() {
        List<String> result = new ArrayList<>();
        // TODO fill results
        return result;
    }

    @Override
    public List<String> getViewNames() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getDDLForTable(String tableName) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getInsertsForTable(String tableName) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getDDLForView(String viewName) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getDumpString() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void dumpToFileName(String fileName) {
        // TODO Auto-generated method stub

    }

    @Override
    public void dumpToSystemOut() {
        // TODO Auto-generated method stub

    }

    @Override
    public String getDatabaseIndexes() {
        // TODO Auto-generated method stub
        return null;
    }

}
